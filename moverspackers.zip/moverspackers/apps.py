from django.apps import AppConfig


class MoverspackersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'moverspackers'
